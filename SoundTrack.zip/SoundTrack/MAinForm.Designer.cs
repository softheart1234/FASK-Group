﻿namespace SoundTrack
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.SoundTrackBar = new System.Windows.Forms.TrackBar();
            this.SpeakButton = new System.Windows.Forms.Button();
            this.SpeechTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.SoundTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(205, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Volume";
            // 
            // SoundTrackBar
            // 
            this.SoundTrackBar.Location = new System.Drawing.Point(283, 209);
            this.SoundTrackBar.Maximum = 100;
            this.SoundTrackBar.Name = "SoundTrackBar";
            this.SoundTrackBar.Size = new System.Drawing.Size(104, 45);
            this.SoundTrackBar.TabIndex = 6;
            this.SoundTrackBar.Value = 75;
            // 
            // SpeakButton
            // 
            this.SpeakButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SpeakButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpeakButton.Location = new System.Drawing.Point(2, 213);
            this.SpeakButton.Name = "SpeakButton";
            this.SpeakButton.Size = new System.Drawing.Size(110, 32);
            this.SpeakButton.TabIndex = 5;
            this.SpeakButton.Text = "Speak";
            this.SpeakButton.UseVisualStyleBackColor = true;
            this.SpeakButton.Click += new System.EventHandler(this.SpeakButton_Click);
            // 
            // SpeechTextBox
            // 
            this.SpeechTextBox.Location = new System.Drawing.Point(2, 2);
            this.SpeechTextBox.Multiline = true;
            this.SpeechTextBox.Name = "SpeechTextBox";
            this.SpeechTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SpeechTextBox.Size = new System.Drawing.Size(396, 189);
            this.SpeechTextBox.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 262);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SoundTrackBar);
            this.Controls.Add(this.SpeakButton);
            this.Controls.Add(this.SpeechTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.SoundTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar SoundTrackBar;
        private System.Windows.Forms.Button SpeakButton;
        private System.Windows.Forms.TextBox SpeechTextBox;
    }
}

